from django.apps import AppConfig


class FbookConfig(AppConfig):
    name = 'fbook'
