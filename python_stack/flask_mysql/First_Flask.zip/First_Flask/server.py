from flask import Flask, render_template,request,redirect
from myconnection import connectToMySQL
# import the function that will return an instance of a connection
app = Flask(__name__)
@app.route("/")
def index():
    print("hello from index")
    mysql = connectToMySQL('first_flask')
    # call the function, passing in the name of our db
    friends = mysql.query_db('SELECT * FROM friends;')  
    # call the query_db function, pass in the query as a string
    print(friends)
    return render_template("index.htm",all_friends=friends)
@app.route("/Add_newuser.htm")
def add_newuser():
    return render_template("add_newuser.htm")

@app.route("/create_user", methods=["POST"])
def create_user():
    print("*"*50, "creating a new user" ,request.form["firstname"])
    
    mySql=connectToMySQL("first_flask")
    query="INSERT INTO friends (first_name, last_name, occupation) VALUES (%(fn)s, %(ln)s, %(occ)s);"
    data={
        "fn":request.form["firstname"],
        "ln":request.form["lastname"],
        "occ":request.form["occupation"]
    }
    mysql = connectToMySQL('first_flask')
    print("Connected to mysql", mysql)
    new_user_id=mysql.query_db(query,data)

    print(f"new_user_id{new_user_id}")
    return redirect("/")


@app.route("/update_user", methods=["POST"])
def update_user():
    print("*"*50, "creating a new user" ,request.form["firstname"],request.form["id"])
    id=request.form["id"]
    mySql=connectToMySQL("first_flask")
    print("its a update")
    query="UPDATE friends SET first_name= %(fn)s, last_name = %(ln)s, occupation = %(occ)s  WHERE id= %(id)s;"
    data={
        "fn":request.form["firstname"],
        "ln":request.form["lastname"],
        "occ":request.form["occupation"],
        "id":request.form["id"]
    }
    mysql = connectToMySQL('first_flask')
    print("Connected to mysql", mysql)
    print(data)
    new_user_id=mysql.query_db(query,data)

    print(f"new_user_id{new_user_id}")
    return redirect("/")




@app.route("/users/<id>/destroy")
def delete_user(id):
    print("delete")
    mySql=connectToMySQL("first_flask")
    query=f"DELETE FROM friends WHERE id={id};"
    mysql = connectToMySQL('first_flask')
    print("Connected to mysql", mysql)
    mysql.query_db(query)
    print("deleted","$"*20)
    return redirect("/")

@app.route("/users/<id>/update")
def user_update(id):
    print("update")
    mysql=connectToMySQL("first_flask")
    query=f"select * from friends where id={id}"
    friend= mysql.query_db(query)
    print(friend,"@"*70)
    return render_template("update_user.htm", friend=friend,update=True)
   
    # print("hello from index")
    # mysql = connectToMySQL('first_flask')
    # # call the function, passing in the name of our db
    # friends = mysql.query_db('SELECT * FROM friends;')  
    # # call the query_db function, pass in the query as a string
    # print(friends)
    # return render_template("index.htm",all_friends=friends)
   
    # query=f"UPDATE friends WHERE SET first_name = {firstname}, last_name = {lastname}, occupation = {occupation} id={id};"
    # mysql = connectToMySQL('first_flask')
    # print("Connected to mysql", mysql)
    # mysql.query_db(query)
    # print("deleted","$"*20)
    

if __name__ == "__main__":
    app.run(debug=True)
